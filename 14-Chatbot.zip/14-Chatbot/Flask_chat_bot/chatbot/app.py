from flask import Flask, render_template, request, jsonify
from llm import get_llm_response

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():

    data = request.get_json()

    prompt = data.get("message", "")

    answer = get_llm_response(prompt)

    return jsonify({
        "response": answer
    })


if __name__ == "__main__":
    app.run(debug=True)
