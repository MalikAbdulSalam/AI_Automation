from llm import get_llm_response

response = get_llm_response("Explain Machine Learning in simple words.")

print(response)
