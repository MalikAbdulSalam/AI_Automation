import os
from groq import Groq
from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Read API key
api_key = os.getenv("GROQ_API_KEY")

# Initialize client
client = Groq(api_key=api_key)


def get_llm_response(prompt: str) -> str:
    """
    Send prompt to Groq and return response.
    """

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {
                "role": "system",
                "content": "You are a helpful AI assistant."
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.7,
        max_tokens=1024
    )

    return response.choices[0].message.content
